Module vfb_connect.neo
======================

Sub-modules
-----------
* vfb_connect.neo.neo4j_tools
* vfb_connect.neo.query_wrapper
* vfb_connect.neo.test