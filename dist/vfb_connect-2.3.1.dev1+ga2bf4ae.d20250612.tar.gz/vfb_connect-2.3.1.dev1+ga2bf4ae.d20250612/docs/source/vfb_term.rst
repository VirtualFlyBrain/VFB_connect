vfb_term package
================

Submodules
----------

schema.vfb_term module
----------------------

.. automodule:: schema.vfb_term
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: schema.vfb_term
   :members:
   :undoc-members:
   :show-inheritance:
