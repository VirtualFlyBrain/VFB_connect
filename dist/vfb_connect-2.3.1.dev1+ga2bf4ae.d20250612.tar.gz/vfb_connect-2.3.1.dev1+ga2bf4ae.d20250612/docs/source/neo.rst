neo package
===========

Submodules
----------

neo.neo4j\_tools module
-----------------------

.. automodule:: vfb_connect.neo.neo4j_tools
   :members:
   :undoc-members:
   :show-inheritance:

neo.query\_wrapper module
-------------------------

.. automodule:: vfb_connect.neo.query_wrapper
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: vfb_connect.neo
   :members:
   :undoc-members:
   :show-inheritance:
